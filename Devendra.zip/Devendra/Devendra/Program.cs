﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Devendra
{
    class Program
    {
        static void Main(string[] args)
        {
            Moth mdev = new Moth(80,220);
            Moth m2dev = new Moth(40,280);
            Moth m3dev = new Moth();
            m2dev.MakeSound();
            mdev.MakeSound();

           m3dev = mdev + m2dev;

           Console.WriteLine(m3dev.ToString());
           m3dev.MakeSound();
         

            Frog frog1 = new Frog(180, 720);
            Frog frog2 = new Frog(200, 780);
            Frog frog3 = new Frog();
            frog1.MakeSound();
            frog2.MakeSound();
            frog3 = frog1 + frog2;
            Console.WriteLine(frog3.ToString());
          
            frog3.MakeSound();  

            Chick chick1 = new Chick(6300, 250);
            Chick chick2 = new Chick(8300, 200);
            Chick chick3 = new Chick();
            chick1.MakeSound();
            chick2.MakeSound();
            chick3 = chick1 + chick2;
            Console.WriteLine(chick3.ToString());
            
            chick3.MakeSound();


            int sum = mdev.GetPrice() + chick1.GetPrice() + frog1.GetPrice();
            Console.WriteLine("Total Price of All Animal of part 1::" + sum);

            int sum1 = m2dev.GetPrice() + chick2.GetPrice() + frog2.GetPrice();
            Console.WriteLine("Total Price of All Animal of part 1::" + sum);

            int sum2 = m3dev.GetPrice() + chick3.GetPrice() + frog3.GetPrice();
            Console.WriteLine("Total Price of All Animal of part 1:::" + sum);




            Zoo zoo = new Zoo();
            zoo.RunZoo();
            Console.ReadLine();

            Console.WriteLine("Enter any Key to continue..");
            Console.ReadKey();v


        }
    }
}
