﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Devendra
{
    abstract class Animal
    {
            public int hertz { get; protected set; }
            public int duration { get; protected set; }

            public int weight { get; protected set; }
            public string name { get; protected set; }
            public Animal()
            {

            }
            public Animal(int _hertz, int _duration, int _weight, string _name)
            {
                this.hertz = _hertz;
                this.duration = _duration;
                this.weight = _weight;
                this.name = _name;
            }

            public virtual int GetPrice()
            {
                return hertz + duration + weight + name.Length;
            }

            public virtual void MakeSound()
            {
                Console.Beep(hertz, duration);
            }

            public override string ToString()
            {
                return "Hertz : " + hertz + "Duration : " + duration + "Weight :" + weight + "Name :" + name;
            }
        }
 }
