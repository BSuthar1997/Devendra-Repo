﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Devendra
{
    class Chick : Animal
    {
        public Chick()
        {

        }

        public Chick(int hertz, int duration)
        {
            this.hertz = hertz;
            this.duration = duration;
            base.weight = 2;
            base.name = "Chick";
        }

        public override int GetPrice()
        {
            return 10 * weight + hertz / 1000;
        }

        public static Chick operator +(Chick c1, Chick c2)
        {
            int h;
            int d;
            if (c1.hertz > c2.hertz)
            {
                h = c1.hertz;
            }
            else
            {
                h = c2.hertz;
            }

            if (c1.duration > c2.duration)
            {
                d = c1.duration;
            }
            else
            {
                d = c2.duration;
            }
            return new Chick(h, d);
        }

        public override void MakeSound()
        {
            Console.WriteLine("Beep");
            base.MakeSound();
        }

    }
}
