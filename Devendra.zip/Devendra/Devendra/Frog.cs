﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Devendra
{
    class Frog : Animal
    {
        public Frog()
        {

        }
        public Frog(int hertz, int duration)
        {
            this.hertz = hertz;
            this.duration = duration;
            base.weight = 3;
            base.name = "Frog";
        }

        public override int GetPrice()
        {
            return 2 * weight + 2 * duration;
        }

        public static Frog operator +(Frog f1, Frog f2)
        {
            return new Frog((f1.hertz + f2.hertz) / 2, (f1.duration + f2.duration) / 2);
        }

        public override void MakeSound()
        {
            Console.WriteLine("Ribbit");
            base.MakeSound();
        }
    }
}
