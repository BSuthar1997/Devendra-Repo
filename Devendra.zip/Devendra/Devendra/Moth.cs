﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Devendra
{
    class Moth : Animal
    {
        public Moth()
        {

        }
       public Moth(int _hertz,int _duration)
       {
            hertz = _hertz;
            duration = _duration;
            base.weight = 1;
            base.name="Moth";

       }
        public static Moth operator +(Moth d, Moth d2)
        {
            return new Moth(d.hertz + d2.hertz, d.duration + d2.duration);
        }
        public override int GetPrice()
        {
            return 8*weight+hertz;
        }
        public override void MakeSound()
        {
            Console.WriteLine("*Moth Noises*");
            base.MakeSound();
        }
        public override string ToString()
        {
            return "Hertz : " + hertz + "Duration : " + duration + "Weight :" + weight + "Name :" + name;
        }

    }
}
