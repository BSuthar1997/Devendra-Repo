﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Devendra
{
    class Zoo
    {
        public enum AnimalType { Frog = 0, Moth = 1, Chick = 2 };
        static Dictionary<AnimalType, Animal> animalDict;
        public Zoo()
        {
            animalDict = new Dictionary<AnimalType, Animal>();
            Frog f4 = new Frog(180, 720);
            Chick c4 = new Chick(6300, 250);
            Moth m4 = new Moth(80, 220);
            animalDict.Add(AnimalType.Frog, f4);
            animalDict.Add(AnimalType.Chick, c4);
            animalDict.Add(AnimalType.Moth, m4);
        }
        public void RunZoo()
        {
            foreach (KeyValuePair<AnimalType, Animal> item in animalDict)
            {
                Console.WriteLine("Key: {0}, Value: {1}", item.Key, item.Value);
                item.Value.MakeSound();
            }

            Moth moth1 = (Moth)animalDict[AnimalType.Moth];
            Moth moth2 = (Moth)animalDict[AnimalType.Moth];
            Moth moth3 = new Moth();
            moth3 = moth1 + moth2;
            Console.WriteLine(moth3.ToString());
            Chick c1 = (Chick)animalDict[AnimalType.Chick];
            Frog f1 = (Frog)animalDict[AnimalType.Frog];
            int sum = moth1.GetPrice() + c1.GetPrice() + f1.GetPrice();
            Console.WriteLine("Total Price of All Animal:" + sum);


        }
    }
}
